import { Link } from "react-router-dom";
import { HiChevronRight } from "react-icons/hi2";


export default function Breadcrumb({
  badge,
  title,
  description,
  currentPage,
  image,
}) {
  return (
    <section
      className="relative flex min-h-[90vh] items-end overflow-hidden pb-24 pt-36 md:min-h-screen md:pt-40 md:pb-28"
      style={{
        backgroundImage: `url(${image})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Uniform dark wash across the whole image */}
      <div className="absolute inset-0 bg-[#081b3a]/45" />
      {/* Bottom-heavy scrim so the text stays readable, like the reference */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />

     <div className="relative mx-auto w-full max-w-7xl px-6 lg:px-8">

        <span className="border-l-2 border-[var(--brand-red-600)] pl-4 text-xs font-bold uppercase tracking-[0.2em] text-white/80">
          {badge}
        </span>

        <h1 className="mt-6 max-w-5xl font-[var(--font-display)] text-5xl font-bold leading-[1.02] text-white md:text-7xl">
          {title}
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-7 text-white/75">
          {description}
        </p>

        <div className="mt-8 flex items-center text-sm text-white/70">

          <Link to="/#">Home</Link>

          <HiChevronRight className="mx-2" />

          <span>{currentPage}</span>

        </div>
</div>

      <div className="absolute bottom-0 left-0 h-px w-full bg-white/25" />
    </section>
  );
}